class Rectangle{
    constructor(width,height) {
        this.width = width;
        this.height = height;
    }
}

const rec1 = new Rectangle(10,15);
console.log("width: ",rec1.width);